plugin.video.comettv
================

Kodi Video Addon for Comet TV Live
For Kodi Isengard and above releases

Version 3.0.5 website change
Version 3.0.4 website change
Version 3.0.3 website change
Version 3.0.2 added more epg entries
Version 3.0.1 separate scraper for future functions

